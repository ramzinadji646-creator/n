const fs = require('fs');

// Créer un CSV simple pour tester l'upload
const csvData = `TCS34725 Color Sensor Data
Reading #,Red (R),Green (G),Blue (B),Clear,Notes
1,165,125,95,210,Normal blood sample
2,158,118,88,195,Normal blood sample
3,172,132,102,225,Normal blood sample

Photodiode Array Data
Reading #,Ch1,Ch2,Ch3,Ch4,Ch5,Ch6,Ch7,Ch8,Ch9,Ch10,Notes
1,1.245,1.332,1.156,1.423,1.298,1.087,1.367,1.112,1.445,1.203,Light absorption values

Impedance Sensor Data
Reading #,Ch1,Ch2,Ch3,Ch4,Ch5,Notes
1,2.34,0.151,0.11,0.15,1.8,Cell counting pulses
2,1.95,0.134,0.098,0.142,2.12,Normal readings`;

fs.writeFileSync('test-sensor-data.csv', csvData);
console.log('✅ Fichier CSV de test créé: test-sensor-data.csv');
console.log('   Contenu: Données de capteurs TCS34725, Photodiode Array et Impedance');
console.log('   Taille:', fs.statSync('test-sensor-data.csv').size, 'bytes');