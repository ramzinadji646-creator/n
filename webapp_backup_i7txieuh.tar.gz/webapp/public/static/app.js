/**
 * CBC Analyzer - Complete Blood Count Analysis Application
 * Version 2.0 - Enhanced with improved accuracy and error handling
 */

class CBCAnalyzer {
    constructor() {
        this.currentStep = 1;
        this.maxStep = 7;
        this.currentLanguage = 'en';
        this.patients = [];
        this.samples = [];
        this.sensorData = {};
        this.processedData = {};
        this.calculatedResults = {};
        this.interpretationResults = {};
        this.currentPatient = null;
        this.currentSample = null;
        this.testHistory = [];
        this.apiUrl = window.location.origin + '/api';
        
        // Reference ranges for CBC parameters (WHO/CLSI standards)
        this.referenceRanges = {
            male: {
                hemoglobin: { min: 13.5, max: 17.5, unit: 'g/dL' },
                rbc: { min: 4.3, max: 5.9, unit: 'M/μL' },
                wbc: { min: 4.5, max: 11.0, unit: 'K/μL' },
                platelets: { min: 150, max: 400, unit: 'K/μL' },
                hematocrit: { min: 41, max: 53, unit: '%' },
                mcv: { min: 82, max: 98, unit: 'fL' },
                mch: { min: 27, max: 32, unit: 'pg' },
                mchc: { min: 32, max: 36, unit: 'g/dL' }
            },
            female: {
                hemoglobin: { min: 12.0, max: 16.0, unit: 'g/dL' },
                rbc: { min: 3.5, max: 5.5, unit: 'M/μL' },
                wbc: { min: 4.5, max: 11.0, unit: 'K/μL' },
                platelets: { min: 150, max: 400, unit: 'K/μL' },
                hematocrit: { min: 36, max: 46, unit: '%' },
                mcv: { min: 82, max: 98, unit: 'fL' },
                mch: { min: 27, max: 32, unit: 'pg' },
                mchc: { min: 32, max: 36, unit: 'g/dL' }
            }
        };

        // Enhanced translations with medical terms
        this.translations = {
            ar: {
                'Patient Entry': 'إدخال المريض',
                'Sample Entry': 'إدخال العينة',
                'Sensor Data': 'بيانات الحساسات',
                'Signal Processing': 'معالجة الإشارات',
                'Medical Calculations': 'الحسابات الطبية',
                'Medical Interpretation': 'التفسير الطبي',
                'Results & Reports': 'النتائج والتقارير',
                'Patient Information': 'معلومات المريض',
                'Patient ID *': 'رقم المريض *',
                'Full Name *': 'الاسم الكامل *',
                'Age *': 'العمر *',
                'Sex *': 'الجنس *',
                'Date *': 'التاريخ *',
                'Add Patient': 'إضافة مريض',
                'Male': 'ذكر',
                'Female': 'أنثى',
                'Select...': 'اختر...',
                'Saved Patients': 'المرضى المحفوظون',
                'Sample ID *': 'رقم العينة *',
                'Patient *': 'المريض *',
                'Collection Date/Time *': 'تاريخ ووقت الجمع *',
                'Add Sample': 'إضافة عينة',
                'Select Patient...': 'اختر مريض...',
                'Sample List': 'قائمة العينات',
                'Generate Sensor Data': 'توليد بيانات الحساسات',
                'Apply Filters': 'تطبيق المرشحات',
                'Calculate CBC': 'حساب فحص الدم',
                'Export CSV': 'تصدير CSV',
                'Generate PDF': 'توليد PDF',
                'Previous': 'السابق',
                'Next': 'التالي',
                'OK': 'موافق',
                'Normal': 'طبيعي',
                'Low': 'منخفض',
                'High': 'مرتفع',
                'Critical': 'حرج',
                'Success': 'نجح',
                'Error': 'خطأ',
                'Warning': 'تحذير',
                'Select': 'اختر',
                'Edit': 'تعديل',
                'Delete': 'حذف',
                'View': 'عرض',
                'Loading...': 'جارٍ التحميل...',
                'Processing...': 'جارٍ المعالجة...',
                'Hemoglobin': 'الهيموغلوبين',
                'RBC Count': 'عدد كريات الدم الحمراء',
                'WBC Count': 'عدد كريات الدم البيضاء',
                'Platelet Count': 'عدد الصفائح الدموية',
                'Hematocrit': 'الهيماتوكريت',
                'Mean Corpuscular Volume': 'الحجم الكروي المتوسط',
                'Mean Corpuscular Hemoglobin': 'الهيموغلوبين الكروي المتوسط',
                'Mean Corpuscular Hemoglobin Concentration': 'تركيز الهيموغلوبين الكروي المتوسط',
                'Download Template': 'تحميل القالب',
                'Download Excel Template': 'تحميل قالب Excel',
                'Generate Random Data': 'توليد بيانات عشوائية',
                'Generate Random': 'توليد عشوائي',
                'Upload Sensor Data (Excel)': 'رفع بيانات الحساسات (Excel)',
                'Select Excel File': 'اختيار ملف Excel',
                'Upload & Process': 'رفع ومعالجة',
                'Sensor Data Input': 'إدخال بيانات الحساسات',
                'Data Source': 'مصدر البيانات',
                'Excel File Upload': 'ملف Excel مرفوع',
                'Uploaded at': 'تم التحميل في',
                'Processing...': 'جارٍ المعالجة...',
                'OR': 'أو'
            }
        };

        this.init();
    }

    init() {
        try {
            this.loadFromStorage();
            this.setupEventListeners();
            this.updateUI();
            this.setDefaultDates();
            this.renderStepContent();
            console.log('CBC Analyzer v2.0 initialized successfully');
        } catch (error) {
            console.error('Initialization error:', error);
            this.showModal('Error', 'Failed to initialize application. Please refresh the page.');
        }
    }

    // Enhanced storage management with error handling
    saveToStorage() {
        try {
            const dataToSave = {
                patients: this.patients,
                samples: this.samples,
                testHistory: this.testHistory,
                currentLanguage: this.currentLanguage,
                timestamp: new Date().toISOString()
            };
            
            localStorage.setItem('cbc_analyzer_data', JSON.stringify(dataToSave));
            console.log('Data saved successfully');
        } catch (error) {
            console.warn('Could not save to localStorage:', error);
            this.showModal('Warning', 'Unable to save data locally. Changes may be lost.');
        }
    }

    loadFromStorage() {
        try {
            const savedData = localStorage.getItem('cbc_analyzer_data');
            
            if (savedData) {
                const data = JSON.parse(savedData);
                this.patients = data.patients || [];
                this.samples = data.samples || [];
                this.testHistory = data.testHistory || [];
                this.currentLanguage = data.currentLanguage || 'en';
            }

            // Load sample data if empty
            if (this.patients.length === 0) {
                this.loadSampleData();
            }
        } catch (error) {
            console.warn('Could not load from localStorage:', error);
            this.loadSampleData();
        }
    }

    loadSampleData() {
        this.patients = [
            { 
                id: 'P001', 
                name: 'أحمد محمد الحسن', 
                age: 35, 
                sex: 'male', 
                date: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString()
            },
            { 
                id: 'P002', 
                name: 'فاطمة علي الزهراء', 
                age: 28, 
                sex: 'female', 
                date: new Date().toISOString().split('T')[0],
                createdAt: new Date().toISOString()
            }
        ];
        this.saveToStorage();
    }

    // Enhanced event listeners with error handling
    setupEventListeners() {
        try {
            // Language change
            const languageSelect = document.getElementById('languageSelect');
            if (languageSelect) {
                languageSelect.addEventListener('change', (e) => {
                    this.changeLanguage(e.target.value);
                });
            }

            // Navigation
            document.querySelectorAll('.nav-step').forEach(step => {
                step.addEventListener('click', (e) => {
                    const stepNum = parseInt(e.currentTarget.dataset.step);
                    if (stepNum) {
                        this.goToStep(stepNum);
                    }
                });
            });

            // Navigation buttons
            const prevBtn = document.getElementById('prevStepBtn');
            const nextBtn = document.getElementById('nextStepBtn');
            
            if (prevBtn) {
                prevBtn.addEventListener('click', () => this.previousStep());
            }
            
            if (nextBtn) {
                nextBtn.addEventListener('click', () => this.nextStep());
            }

            // Modal controls
            const modalCloseBtn = document.getElementById('modalCloseBtn');
            const modalOkBtn = document.getElementById('modalOkBtn');
            
            if (modalCloseBtn) {
                modalCloseBtn.addEventListener('click', () => this.hideModal());
            }
            
            if (modalOkBtn) {
                modalOkBtn.addEventListener('click', () => this.hideModal());
            }

            // Global error handler
            window.addEventListener('error', (e) => {
                console.error('Global error:', e.error);
                this.showModal('Error', 'An unexpected error occurred. Please try again.');
            });

            console.log('Event listeners setup completed');
        } catch (error) {
            console.error('Error setting up event listeners:', error);
        }
    }

    // Language Management
    changeLanguage(lang) {
        try {
            this.currentLanguage = lang;
            document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
            document.documentElement.lang = lang;
            this.updateTranslations();
            this.saveToStorage();
            console.log(`Language changed to: ${lang}`);
        } catch (error) {
            console.error('Error changing language:', error);
        }
    }

    translate(key) {
        if (this.currentLanguage === 'ar' && this.translations.ar[key]) {
            return this.translations.ar[key];
        }
        return key;
    }

    updateTranslations() {
        document.querySelectorAll('[data-en]').forEach(element => {
            const englishText = element.getAttribute('data-en');
            const arabicText = element.getAttribute('data-ar');
            
            if (this.currentLanguage === 'ar' && arabicText) {
                element.textContent = arabicText;
            } else {
                element.textContent = englishText;
            }
        });
    }

    // Enhanced Navigation with validation
    goToStep(stepNum) {
        if (stepNum < 1 || stepNum > this.maxStep) {
            console.warn(`Invalid step number: ${stepNum}`);
            return;
        }
        
        // Validate current step before proceeding
        if (stepNum > this.currentStep && !this.validateCurrentStep()) {
            this.showModal(
                this.translate('Error'), 
                'Please complete the current step before proceeding.'
            );
            return;
        }
        
        this.currentStep = stepNum;
        this.updateStepDisplay();
        this.updateNavigationButtons();
        this.renderStepContent();
        
        console.log(`Navigated to step: ${stepNum}`);
    }

    nextStep() {
        if (this.currentStep < this.maxStep) {
            this.goToStep(this.currentStep + 1);
        }
    }

    previousStep() {
        if (this.currentStep > 1) {
            this.goToStep(this.currentStep - 1);
        }
    }

    updateStepDisplay() {
        // Update navigation steps
        document.querySelectorAll('.nav-step').forEach(step => {
            const stepNum = parseInt(step.dataset.step);
            step.classList.remove('active', 'completed');
            
            if (stepNum === this.currentStep) {
                step.classList.add('active');
            } else if (stepNum < this.currentStep) {
                step.classList.add('completed');
            }
        });
    }

    updateNavigationButtons() {
        const prevBtn = document.getElementById('prevStepBtn');
        const nextBtn = document.getElementById('nextStepBtn');

        if (prevBtn) {
            prevBtn.disabled = this.currentStep === 1;
        }
        
        if (nextBtn) {
            nextBtn.textContent = this.currentStep === this.maxStep ? 
                this.translate('Finish') : this.translate('Next');
        }
    }

    validateCurrentStep() {
        switch (this.currentStep) {
            case 1:
                return this.patients.length > 0;
            case 2:
                return this.samples.length > 0 && this.currentPatient && this.currentSample;
            case 3:
                return Object.keys(this.sensorData).length > 0;
            case 4:
                return Object.keys(this.processedData).length > 0;
            case 5:
                return Object.keys(this.calculatedResults).length > 0;
            case 6:
                return Object.keys(this.interpretationResults).length > 0;
            default:
                return true;
        }
    }

    // Enhanced content rendering
    renderStepContent() {
        const contentContainer = document.getElementById('app-content');
        if (!contentContainer) return;

        let content = '';

        switch (this.currentStep) {
            case 1:
                content = this.renderPatientStep();
                break;
            case 2:
                content = this.renderSampleStep();
                break;
            case 3:
                content = this.renderSensorStep();
                break;
            case 4:
                content = this.renderProcessingStep();
                break;
            case 5:
                content = this.renderCalculationStep();
                break;
            case 6:
                content = this.renderInterpretationStep();
                break;
            case 7:
                content = this.renderResultsStep();
                break;
            default:
                content = '<div class="loading-screen"><i class="fas fa-spinner fa-spin"></i><p>Loading...</p></div>';
        }

        contentContainer.innerHTML = content;
        this.setupStepEventListeners();
        this.updateTranslations();
    }

    renderPatientStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Patient Information" data-ar="معلومات المريض">Patient Information</h2>
                    <button class="btn btn--primary" id="addPatientBtn" data-en="Add Patient" data-ar="إضافة مريض">
                        <i class="fas fa-plus"></i> Add Patient
                    </button>
                </div>
                <div class="card__body">
                    <form id="patientForm" class="form-grid">
                        <div class="form-group">
                            <label class="form-label" data-en="Patient ID *" data-ar="رقم المريض *">Patient ID *</label>
                            <input type="text" class="form-control" id="patientId" placeholder="P001" required>
                            <div class="error-message hidden" id="patientIdError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Full Name *" data-ar="الاسم الكامل *">Full Name *</label>
                            <input type="text" class="form-control" id="patientName" placeholder="أحمد محمد" required>
                            <div class="error-message hidden" id="patientNameError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Age *" data-ar="العمر *">Age *</label>
                            <input type="number" class="form-control" id="patientAge" min="0" max="120" required>
                            <div class="error-message hidden" id="patientAgeError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Sex *" data-ar="الجنس *">Sex *</label>
                            <select class="form-control" id="patientSex" required>
                                <option value="" data-en="Select..." data-ar="اختر...">Select...</option>
                                <option value="male" data-en="Male" data-ar="ذكر">Male</option>
                                <option value="female" data-en="Female" data-ar="أنثى">Female</option>
                            </select>
                            <div class="error-message hidden" id="patientSexError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Date *" data-ar="التاريخ *">Date *</label>
                            <input type="date" class="form-control" id="patientDate" required>
                            <div class="error-message hidden" id="patientDateError"></div>
                        </div>
                    </form>
                    
                    <div class="patient-list">
                        <h3 data-en="Saved Patients" data-ar="المرضى المحفوظون">Saved Patients</h3>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th data-en="ID" data-ar="الرقم">ID</th>
                                        <th data-en="Name" data-ar="الاسم">Name</th>
                                        <th data-en="Age" data-ar="العمر">Age</th>
                                        <th data-en="Sex" data-ar="الجنس">Sex</th>
                                        <th data-en="Date" data-ar="التاريخ">Date</th>
                                        <th data-en="Actions" data-ar="الإجراءات">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="patientTableBody">
                                    ${this.renderPatientTable()}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderPatientTable() {
        return this.patients.map(patient => `
            <tr>
                <td>${patient.id}</td>
                <td>${patient.name}</td>
                <td>${patient.age}</td>
                <td data-en="${patient.sex === 'male' ? 'Male' : 'Female'}" data-ar="${patient.sex === 'male' ? 'ذكر' : 'أنثى'}">${patient.sex === 'male' ? 'Male' : 'Female'}</td>
                <td>${new Date(patient.date).toLocaleDateString()}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="app.selectPatient('${patient.id}')">
                            <i class="fas fa-check"></i> <span data-en="Select" data-ar="اختر">Select</span>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="app.editPatient('${patient.id}')">
                            <i class="fas fa-edit"></i> <span data-en="Edit" data-ar="تعديل">Edit</span>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="app.deletePatient('${patient.id}')">
                            <i class="fas fa-trash"></i> <span data-en="Delete" data-ar="حذف">Delete</span>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    renderSampleStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Sample Entry" data-ar="إدخال العينة">Sample Entry</h2>
                    <button class="btn btn--primary" id="addSampleBtn" data-en="Add Sample" data-ar="إضافة عينة">
                        <i class="fas fa-vial"></i> Add Sample
                    </button>
                </div>
                <div class="card__body">
                    ${this.currentPatient ? `
                        <div class="alert alert--info" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-1); border-radius: 8px; border-left: 4px solid var(--color-primary);">
                            <strong>${this.translate('Selected Patient')}:</strong> ${this.currentPatient.name} (${this.currentPatient.id})
                        </div>
                    ` : `
                        <div class="alert alert--warning" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-4); border-radius: 8px; border-left: 4px solid var(--color-warning);">
                            <strong>${this.translate('Warning')}:</strong> ${this.translate('Please select a patient first from Step 1')}
                        </div>
                    `}
                    
                    <form id="sampleForm" class="form-grid">
                        <div class="form-group">
                            <label class="form-label" data-en="Sample ID *" data-ar="رقم العينة *">Sample ID *</label>
                            <input type="text" class="form-control" id="sampleId" placeholder="S001" required>
                            <div class="error-message hidden" id="sampleIdError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Patient *" data-ar="المريض *">Patient *</label>
                            <select class="form-control" id="samplePatientId" required>
                                <option value="" data-en="Select Patient..." data-ar="اختر مريض...">Select Patient...</option>
                                ${this.patients.map(p => `
                                    <option value="${p.id}" ${this.currentPatient && this.currentPatient.id === p.id ? 'selected' : ''}>
                                        ${p.id} - ${p.name}
                                    </option>
                                `).join('')}
                            </select>
                            <div class="error-message hidden" id="samplePatientIdError"></div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" data-en="Collection Date/Time *" data-ar="تاريخ ووقت الجمع *">Collection Date/Time *</label>
                            <input type="datetime-local" class="form-control" id="sampleDateTime" required>
                            <div class="error-message hidden" id="sampleDateTimeError"></div>
                        </div>
                    </form>
                    
                    <div class="sample-list">
                        <h3 data-en="Sample List" data-ar="قائمة العينات">Sample List</h3>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th data-en="Sample ID" data-ar="رقم العينة">Sample ID</th>
                                        <th data-en="Patient Name" data-ar="اسم المريض">Patient Name</th>
                                        <th data-en="Collection Date" data-ar="تاريخ الجمع">Collection Date</th>
                                        <th data-en="Actions" data-ar="الإجراءات">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${this.renderSampleTable()}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderSampleTable() {
        return this.samples.map(sample => `
            <tr>
                <td>${sample.id}</td>
                <td>${sample.patientName}</td>
                <td>${new Date(sample.dateTime).toLocaleString()}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="app.selectSample('${sample.id}')">
                            <i class="fas fa-check"></i> <span data-en="Select" data-ar="اختر">Select</span>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="app.deleteSample('${sample.id}')">
                            <i class="fas fa-trash"></i> <span data-en="Delete" data-ar="حذف">Delete</span>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    renderSensorStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Sensor Data Input" data-ar="إدخال بيانات الحساسات">Sensor Data Input</h2>
                    <div class="header-actions" style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <button class="btn btn--secondary" id="downloadTemplateBtn" data-en="Download Template" data-ar="تحميل القالب">
                            <i class="fas fa-download"></i> <span data-en="Download Excel Template" data-ar="تحميل قالب Excel">Download Template</span>
                        </button>
                        <button class="btn btn--primary" id="generateSensorBtn" data-en="Generate Random Data" data-ar="توليد بيانات عشوائية">
                            <i class="fas fa-microchip"></i> <span data-en="Generate Random" data-ar="توليد عشوائي">Generate Random</span>
                        </button>
                    </div>
                </div>
                <div class="card__body">
                    ${this.currentSample ? `
                        <div class="alert alert--info" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-1); border-radius: 8px; border-left: 4px solid var(--color-primary);">
                            <strong>${this.translate('Selected Sample')}:</strong> ${this.currentSample.id} - ${this.currentSample.patientName}
                        </div>
                    ` : `
                        <div class="alert alert--warning" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-4); border-radius: 8px; border-left: 4px solid var(--color-warning);">
                            <strong>${this.translate('Warning')}:</strong> ${this.translate('Please select a sample first from Step 2')}
                        </div>
                    `}
                    
                    <!-- File Upload Section -->
                    <div class="upload-section" style="margin-bottom: 24px;">
                        <h3 data-en="Upload Sensor Data (Excel)" data-ar="رفع بيانات الحساسات (Excel)">Upload Sensor Data (Excel)</h3>
                        <div class="upload-container" style="border: 2px dashed var(--color-border); border-radius: 8px; padding: 20px; text-align: center; margin-bottom: 16px;">
                            <input type="file" id="sensorExcelFile" accept=".xlsx,.xls" style="display: none;">
                            <button class="btn btn--outline" id="selectExcelBtn" style="margin-bottom: 12px;">
                                <i class="fas fa-file-excel"></i> <span data-en="Select Excel File" data-ar="اختيار ملف Excel">Select Excel File</span>
                            </button>
                            <div id="selectedFileName" style="color: var(--color-text-secondary); font-size: 14px; margin-bottom: 12px;"></div>
                            <button class="btn btn--primary" id="uploadExcelBtn" style="display: none;">
                                <i class="fas fa-upload"></i> <span data-en="Upload & Process" data-ar="رفع ومعالجة">Upload & Process</span>
                            </button>
                        </div>
                        <div class="upload-help" style="font-size: 12px; color: var(--color-text-secondary);">
                            <p data-en="• Upload an Excel file with sensor data in the correct format" data-ar="• قم برفع ملف Excel يحتوي على بيانات الحساسات بالتنسيق الصحيح">• Upload an Excel file with sensor data in the correct format</p>
                            <p data-en="• Download the template above to see the required format" data-ar="• قم بتحميل القالب أعلاه لرؤية التنسيق المطلوب">• Download the template above to see the required format</p>
                            <p data-en="• Supported formats: .xlsx, .xls" data-ar="• التنسيقات المدعومة: .xlsx, .xls">• Supported formats: .xlsx, .xls</p>
                        </div>
                    </div>
                    
                    <div class="divider" style="border-bottom: 1px solid var(--color-border); margin: 24px 0; text-align: center;">
                        <span style="background: var(--color-surface); padding: 0 16px; color: var(--color-text-secondary); font-size: 14px;" data-en="OR" data-ar="أو">OR</span>
                    </div>
                    
                    <div class="sensor-outputs">
                        <div class="sensor-section">
                            <h4 data-en="TCS34725 Color Sensor" data-ar="حساس الألوان TCS34725">TCS34725 Color Sensor</h4>
                            <div class="sensor-values">
                                <div class="value-item">
                                    <label data-en="Red (R)" data-ar="أحمر (R)">Red (R)</label>
                                    <span id="sensorR">-</span>
                                </div>
                                <div class="value-item">
                                    <label data-en="Green (G)" data-ar="أخضر (G)">Green (G)</label>
                                    <span id="sensorG">-</span>
                                </div>
                                <div class="value-item">
                                    <label data-en="Blue (B)" data-ar="أزرق (B)">Blue (B)</label>
                                    <span id="sensorB">-</span>
                                </div>
                                <div class="value-item">
                                    <label data-en="Clear" data-ar="شفاف">Clear</label>
                                    <span id="sensorClear">-</span>
                                </div>
                            </div>
                        </div>

                        <div class="sensor-section">
                            <h4 data-en="Photodiode Array (10 values)" data-ar="مصفوفة الضوئي (10 قيم)">Photodiode Array (10 values)</h4>
                            <div class="array-values" id="photodiodeValues">
                                ${this.sensorData.photodiode ? this.sensorData.photodiode.map(val => `<div class="array-value">${val}</div>`).join('') : '<p>No data generated yet</p>'}
                            </div>
                        </div>

                        <div class="sensor-section">
                            <h4 data-en="Impedance Sensor (20 values)" data-ar="حساس المقاومة (20 قيمة)">Impedance Sensor (20 values)</h4>
                            <div class="array-values" id="impedanceValues">
                                ${this.sensorData.impedance ? this.sensorData.impedance.map(val => `<div class="array-value">${val}</div>`).join('') : '<p>No data generated yet</p>'}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderProcessingStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Signal Processing" data-ar="معالجة الإشارات">Signal Processing</h2>
                    <button class="btn btn--primary" id="processSignalsBtn" data-en="Apply Filters" data-ar="تطبيق المرشحات">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                </div>
                <div class="card__body">
                    ${Object.keys(this.sensorData).length === 0 ? `
                        <div class="alert alert--warning" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-4); border-radius: 8px; border-left: 4px solid var(--color-warning);">
                            <strong>${this.translate('Warning')}:</strong> ${this.translate('Please generate sensor data first from Step 3')}
                        </div>
                    ` : ''}
                    
                    <div class="filter-options">
                        <div class="filter-group">
                            <h4 data-en="Filter Options" data-ar="خيارات المرشحات">Filter Options</h4>
                            <div class="checkbox-group">
                                <label>
                                    <input type="checkbox" id="movingAvg3" checked>
                                    <span data-en="Moving Average (3)" data-ar="المتوسط المتحرك (3)">Moving Average (3)</span>
                                </label>
                                <label>
                                    <input type="checkbox" id="movingAvg5" checked>
                                    <span data-en="Moving Average (5)" data-ar="المتوسط المتحرك (5)">Moving Average (5)</span>
                                </label>
                                <label>
                                    <input type="checkbox" id="movingAvg7">
                                    <span data-en="Moving Average (7)" data-ar="المتوسط المتحرك (7)">Moving Average (7)</span>
                                </label>
                                <label>
                                    <input type="checkbox" id="medianFilter3" checked>
                                    <span data-en="Median Filter (3)" data-ar="مرشح متوسط (3)">Median Filter (3)</span>
                                </label>
                                <label>
                                    <input type="checkbox" id="medianFilter5">
                                    <span data-en="Median Filter (5)" data-ar="مرشح متوسط (5)">Median Filter (5)</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="processing-results">
                        <h4 data-en="Signal Quality Metrics" data-ar="مقاييس جودة الإشارة">Signal Quality Metrics</h4>
                        <div class="metrics-grid" id="signalMetrics">
                            ${this.renderSignalMetrics()}
                        </div>
                    </div>

                    <div class="chart-section">
                        <h4 data-en="Before/After Comparison" data-ar="مقارنة قبل وبعد">Before/After Comparison</h4>
                        <div class="chart-container" style="height: 300px; position: relative;">
                            <canvas id="signalChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderSignalMetrics() {
        if (!this.processedData.metrics) {
            return '<p>Process signal first to see metrics</p>';
        }

        const metrics = this.processedData.metrics;
        return `
            <div class="metric-card">
                <div class="metric-title">Original SNR</div>
                <div class="metric-value">${metrics.originalSNR}<span class="metric-unit">dB</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-title">Processed SNR</div>
                <div class="metric-value">${metrics.processedSNR}<span class="metric-unit">dB</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-title">SNR Improvement</div>
                <div class="metric-value">${metrics.snrImprovement >= 0 ? '+' : ''}${metrics.snrImprovement}<span class="metric-unit">dB</span></div>
            </div>
            <div class="metric-card">
                <div class="metric-title">Filters Applied</div>
                <div class="metric-value">${this.processedData.filters?.length || 0}</div>
            </div>
        `;
    }

    renderCalculationStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Medical Calculations" data-ar="الحسابات الطبية">Medical Calculations</h2>
                    <button class="btn btn--primary" id="calculateCBCBtn" data-en="Calculate CBC" data-ar="حساب فحص الدم">
                        <i class="fas fa-calculator"></i> Calculate CBC
                    </button>
                </div>
                <div class="card__body">
                    ${Object.keys(this.processedData).length === 0 ? `
                        <div class="alert alert--warning" style="margin-bottom: 20px; padding: 12px; background: var(--color-bg-4); border-radius: 8px; border-left: 4px solid var(--color-warning);">
                            <strong>${this.translate('Warning')}:</strong> ${this.translate('Please process signal data first from Step 4')}
                        </div>
                    ` : ''}
                    
                    <div class="calculation-results" id="calculationResults">
                        ${this.renderCalculationResults()}
                    </div>
                    
                    <div class="formulas-section">
                        <h4 data-en="Calculation Formulas Used" data-ar="الصيغ المستخدمة في الحساب">Calculation Formulas Used</h4>
                        <div class="formula-list" id="formulaList">
                            ${this.renderFormulas()}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderCalculationResults() {
        if (!this.calculatedResults || Object.keys(this.calculatedResults).length <= 1) {
            return '<p>No calculation results yet. Click "Calculate CBC" to generate results.</p>';
        }

        return Object.keys(this.calculatedResults)
            .filter(key => key !== 'timestamp' && key !== 'patientId')
            .map(param => {
                const result = this.calculatedResults[param];
                return `
                    <div class="calculation-item">
                        <div class="calculation-info">
                            <h5>${this.translate(param.toUpperCase())}</h5>
                            <div class="formula">${result.formula}</div>
                            <div class="method" style="font-size: 11px; color: var(--color-text-secondary); margin-top: 4px;">
                                Method: ${result.method}
                            </div>
                        </div>
                        <div class="calculation-result">
                            <div class="result-value">${result.value}<span class="result-unit">${result.unit}</span></div>
                            <div class="normal-range" style="font-size: 11px; color: var(--color-text-secondary); margin-top: 4px;">
                                Normal: ${result.normalRange ? 
                                    (this.currentPatient && this.currentPatient.sex ? 
                                        result.normalRange[this.currentPatient.sex] || result.normalRange.universal || result.normalRange.male
                                        : result.normalRange.universal || result.normalRange.male) 
                                    : 'N/A'
                                }
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
    }

    renderFormulas() {
        if (!this.calculatedResults || Object.keys(this.calculatedResults).length <= 1) {
            return '<p>No formulas to display yet.</p>';
        }

        return Object.keys(this.calculatedResults)
            .filter(key => key !== 'timestamp' && key !== 'patientId')
            .map(param => {
                const result = this.calculatedResults[param];
                return `
                    <div class="formula-item">
                        <div class="formula-name">${param.toUpperCase()}</div>
                        <div class="formula-expression">${result.formula}</div>
                    </div>
                `;
            }).join('');
    }

    renderInterpretationStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Medical Interpretation" data-ar="التفسير الطبي">Medical Interpretation</h2>
                    <button class="btn btn--secondary" id="refreshInterpretationBtn" data-en="Refresh Interpretation" data-ar="تحديث التفسير">
                        <i class="fas fa-refresh"></i> Refresh
                    </button>
                </div>
                <div class="card__body">
                    <div class="interpretation-results" id="interpretationResults">
                        ${this.renderInterpretationResults()}
                    </div>
                    
                    <div class="reference-ranges">
                        <h4 data-en="Reference Ranges" data-ar="المعدلات المرجعية">Reference Ranges</h4>
                        <div class="ranges-grid">
                            ${this.renderReferenceRanges()}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderInterpretationResults() {
        if (!this.interpretationResults || !this.interpretationResults.interpretations) {
            return '<p>No interpretation results yet. Interpretation will be generated automatically when calculations are complete.</p>';
        }

        const interpretations = this.interpretationResults.interpretations;
        const overallAssessment = this.interpretationResults.overallAssessment;

        let content = `
            <div class="interpretation-item overall ${this.getOverallStatus()}">
                <div class="interpretation-title">Overall Assessment</div>
                <div class="interpretation-text">${overallAssessment}</div>
            </div>
        `;

        content += interpretations.map(interp => `
            <div class="interpretation-item ${interp.status}">
                <div class="interpretation-title">
                    ${this.translate(interp.parameter.toUpperCase())}: ${interp.value} ${interp.unit}
                    <span class="interpretation-flag ${interp.status}">${interp.flag}</span>
                </div>
                <div class="interpretation-text">
                    Reference Range (${this.currentPatient ? this.translate(this.currentPatient.sex === 'male' ? 'Male' : 'Female') : 'N/A'}): ${interp.referenceRange}<br>
                    ${interp.interpretation}
                </div>
            </div>
        `).join('');

        return content;
    }

    getOverallStatus() {
        if (!this.interpretationResults || !this.interpretationResults.interpretations) return 'normal';
        
        const interpretations = this.interpretationResults.interpretations;
        const hasCritical = interpretations.some(i => i.status === 'critical');
        const hasAbnormal = interpretations.some(i => i.status === 'low' || i.status === 'high');
        
        if (hasCritical) return 'critical';
        if (hasAbnormal) return 'abnormal';
        return 'normal';
    }

    renderReferenceRanges() {
        const ranges = this.referenceRanges;
        
        return Object.keys(ranges.male).map(param => `
            <div class="range-card">
                <div class="range-parameter">${this.translate(param.toUpperCase())}</div>
                <div class="range-values">
                    <div class="range-male">
                        <span class="range-label" data-en="Male" data-ar="ذكر">Male</span>
                        <span class="range-value">${ranges.male[param].min}-${ranges.male[param].max} ${ranges.male[param].unit}</span>
                    </div>
                    <div class="range-female">
                        <span class="range-label" data-en="Female" data-ar="أنثى">Female</span>
                        <span class="range-value">${ranges.female[param].min}-${ranges.female[param].max} ${ranges.female[param].unit}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderResultsStep() {
        return `
            <div class="card">
                <div class="card__header">
                    <h2 data-en="Results & Reports" data-ar="النتائج والتقارير">Results & Reports</h2>
                    <div class="header-actions" style="display: flex; gap: 8px;">
                        <button class="btn btn--secondary" id="exportCSVBtn" data-en="Export CSV" data-ar="تصدير CSV">
                            <i class="fas fa-file-csv"></i> Export CSV
                        </button>
                        <button class="btn btn--primary" id="generatePDFBtn" data-en="Generate PDF" data-ar="توليد PDF">
                            <i class="fas fa-file-pdf"></i> Generate PDF
                        </button>
                    </div>
                </div>
                <div class="card__body">
                    <div class="results-summary" id="resultsSummary">
                        ${this.renderResultsSummary()}
                    </div>
                    
                    <div class="test-history">
                        <h4 data-en="Test History" data-ar="تاريخ الفحوصات">Test History</h4>
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th data-en="Date" data-ar="التاريخ">Date</th>
                                        <th data-en="Patient" data-ar="المريض">Patient</th>
                                        <th data-en="Sample" data-ar="العينة">Sample</th>
                                        <th data-en="Status" data-ar="الحالة">Status</th>
                                        <th data-en="Actions" data-ar="الإجراءات">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${this.renderTestHistory()}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderResultsSummary() {
        if (!this.currentPatient || !this.currentSample || !this.calculatedResults || Object.keys(this.calculatedResults).length <= 1) {
            return `
                <div class="alert alert--info" style="padding: 20px; text-align: center;">
                    <i class="fas fa-info-circle" style="font-size: 24px; color: var(--color-primary); margin-bottom: 12px;"></i>
                    <p>${this.translate('Complete the workflow to see results summary')}</p>
                    <p style="font-size: 12px; color: var(--color-text-secondary);">
                        ${this.translate('Ensure you have selected a patient, added a sample, and completed CBC calculations')}
                    </p>
                </div>
            `;
        }

        return `
            <div class="summary-header">
                <div class="summary-title">CBC Analysis Report</div>
                <div class="summary-date">${new Date().toLocaleString()}</div>
            </div>
            <div class="summary-content">
                <div class="patient-info">
                    <div class="info-title">${this.translate('Patient Information')}</div>
                    <div class="info-item">
                        <span class="info-label">ID:</span>
                        <span class="info-value">${this.currentPatient.id}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Name:</span>
                        <span class="info-value">${this.currentPatient.name}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Age:</span>
                        <span class="info-value">${this.currentPatient.age} years</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Sex:</span>
                        <span class="info-value">${this.translate(this.currentPatient.sex === 'male' ? 'Male' : 'Female')}</span>
                    </div>
                </div>
                <div class="sample-info">
                    <div class="info-title">${this.translate('Sample Information')}</div>
                    <div class="info-item">
                        <span class="info-label">Sample ID:</span>
                        <span class="info-value">${this.currentSample.id}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Collection:</span>
                        <span class="info-value">${new Date(this.currentSample.dateTime).toLocaleString()}</span>
                    </div>
                </div>
                <div class="results-info">
                    <div class="info-title">${this.translate('Results Summary')}</div>
                    ${Object.keys(this.calculatedResults).filter(k => k !== 'timestamp' && k !== 'patientId').map(param => `
                        <div class="info-item">
                            <span class="info-label">${this.translate(param.toUpperCase())}:</span>
                            <span class="info-value">${this.calculatedResults[param].value} ${this.calculatedResults[param].unit}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    renderTestHistory() {
        if (this.testHistory.length === 0) {
            return `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 20px; color: var(--color-text-secondary);">
                        No test history available
                    </td>
                </tr>
            `;
        }

        return this.testHistory.map((test, index) => `
            <tr>
                <td>${new Date(test.timestamp).toLocaleDateString()}</td>
                <td>${test.patientName}</td>
                <td>${test.sampleId}</td>
                <td><span class="status status--success">Completed</span></td>
                <td>
                    <button class="btn btn--sm btn--secondary" onclick="app.viewTestResult(${index})">
                        <i class="fas fa-eye"></i> ${this.translate('View')}
                    </button>
                </td>
            </tr>
        `).join('');
    }

    // Enhanced step-specific event listeners
    setupStepEventListeners() {
        try {
            switch (this.currentStep) {
                case 1:
                    this.setupPatientEventListeners();
                    break;
                case 2:
                    this.setupSampleEventListeners();
                    break;
                case 3:
                    this.setupSensorEventListeners();
                    break;
                case 4:
                    this.setupProcessingEventListeners();
                    break;
                case 5:
                    this.setupCalculationEventListeners();
                    break;
                case 6:
                    this.setupInterpretationEventListeners();
                    break;
                case 7:
                    this.setupResultsEventListeners();
                    break;
            }
        } catch (error) {
            console.error('Error setting up step event listeners:', error);
        }
    }

    setupPatientEventListeners() {
        const addBtn = document.getElementById('addPatientBtn');
        if (addBtn) {
            addBtn.addEventListener('click', () => this.addPatient());
        }

        // Form validation
        const form = document.getElementById('patientForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addPatient();
            });
        }

        // Real-time validation
        ['patientId', 'patientName', 'patientAge', 'patientSex', 'patientDate'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.addEventListener('input', () => this.validatePatientForm());
            }
        });
    }

    setupSampleEventListeners() {
        const addBtn = document.getElementById('addSampleBtn');
        if (addBtn) {
            addBtn.addEventListener('click', () => this.addSample());
        }

        const patientSelect = document.getElementById('samplePatientId');
        if (patientSelect) {
            patientSelect.addEventListener('change', (e) => {
                const patientId = e.target.value;
                if (patientId) {
                    this.currentPatient = this.patients.find(p => p.id === patientId);
                }
            });
        }

        // Set default datetime
        const datetimeField = document.getElementById('sampleDateTime');
        if (datetimeField && !datetimeField.value) {
            const now = new Date();
            now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
            datetimeField.value = now.toISOString().slice(0, 16);
        }
    }

    setupSensorEventListeners() {
        // Random generation button
        const generateBtn = document.getElementById('generateSensorBtn');
        if (generateBtn) {
            generateBtn.addEventListener('click', () => this.generateSensorData());
        }

        // Template download button
        const downloadTemplateBtn = document.getElementById('downloadTemplateBtn');
        if (downloadTemplateBtn) {
            downloadTemplateBtn.addEventListener('click', () => this.downloadExcelTemplate());
        }

        // File selection
        const selectExcelBtn = document.getElementById('selectExcelBtn');
        const fileInput = document.getElementById('sensorExcelFile');
        const uploadBtn = document.getElementById('uploadExcelBtn');
        const selectedFileName = document.getElementById('selectedFileName');

        if (selectExcelBtn && fileInput) {
            selectExcelBtn.addEventListener('click', () => {
                fileInput.click();
            });

            fileInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    selectedFileName.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
                    if (uploadBtn) {
                        uploadBtn.style.display = 'inline-flex';
                    }
                } else {
                    selectedFileName.textContent = '';
                    if (uploadBtn) {
                        uploadBtn.style.display = 'none';
                    }
                }
            });
        }

        // File upload
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.uploadExcelFile());
        }
    }

    setupProcessingEventListeners() {
        const processBtn = document.getElementById('processSignalsBtn');
        if (processBtn) {
            processBtn.addEventListener('click', () => this.processSignals());
        }
    }

    setupCalculationEventListeners() {
        const calculateBtn = document.getElementById('calculateCBCBtn');
        if (calculateBtn) {
            calculateBtn.addEventListener('click', () => this.calculateCBC());
        }
    }

    setupInterpretationEventListeners() {
        const refreshBtn = document.getElementById('refreshInterpretationBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.updateInterpretation());
        }

        // Auto-generate interpretation if not already done
        if (this.calculatedResults && Object.keys(this.calculatedResults).length > 1 && 
            (!this.interpretationResults || !this.interpretationResults.interpretations)) {
            setTimeout(() => this.updateInterpretation(), 500);
        }
    }

    setupResultsEventListeners() {
        const exportBtn = document.getElementById('exportCSVBtn');
        const pdfBtn = document.getElementById('generatePDFBtn');

        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportCSV());
        }

        if (pdfBtn) {
            pdfBtn.addEventListener('click', () => this.generatePDF());
        }
    }

    // Enhanced API methods
    async addPatient() {
        try {
            const formData = this.getPatientFormData();
            
            const response = await fetch(`${this.apiUrl}/patients`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.success) {
                this.patients.push(result.patient);
                this.saveToStorage();
                this.clearPatientForm();
                this.renderStepContent();
                this.showModal(this.translate('Success'), 'Patient added successfully');
            } else {
                this.showModal(this.translate('Error'), result.errors?.join('\n') || 'Failed to add patient');
            }
        } catch (error) {
            console.error('Error adding patient:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    getPatientFormData() {
        return {
            id: document.getElementById('patientId')?.value.trim() || this.generatePatientId(),
            name: document.getElementById('patientName')?.value.trim() || '',
            age: parseInt(document.getElementById('patientAge')?.value) || 0,
            sex: document.getElementById('patientSex')?.value || '',
            date: document.getElementById('patientDate')?.value || new Date().toISOString().split('T')[0]
        };
    }

    generatePatientId() {
        return 'P' + Date.now().toString().slice(-6);
    }

    clearPatientForm() {
        ['patientId', 'patientName', 'patientAge', 'patientSex', 'patientDate'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.value = '';
                field.classList.remove('error', 'success');
            }
        });

        // Set default date
        const dateField = document.getElementById('patientDate');
        if (dateField) {
            dateField.value = new Date().toISOString().split('T')[0];
        }
    }

    validatePatientForm() {
        const fields = ['patientId', 'patientName', 'patientAge', 'patientSex', 'patientDate'];
        let isValid = true;

        fields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            const errorElement = document.getElementById(fieldId + 'Error');
            
            if (!field) return;

            let fieldValid = true;
            let errorMessage = '';

            if (field.hasAttribute('required') && !field.value.trim()) {
                fieldValid = false;
                errorMessage = 'This field is required';
            } else if (fieldId === 'patientAge') {
                const age = parseInt(field.value);
                if (isNaN(age) || age < 0 || age > 120) {
                    fieldValid = false;
                    errorMessage = 'Age must be between 0 and 120';
                }
            }

            if (!fieldValid) {
                field.classList.add('error');
                field.classList.remove('success');
                if (errorElement) {
                    errorElement.textContent = errorMessage;
                    errorElement.classList.remove('hidden');
                }
                isValid = false;
            } else {
                field.classList.remove('error');
                field.classList.add('success');
                if (errorElement) {
                    errorElement.classList.add('hidden');
                }
            }
        });

        return isValid;
    }

    async addSample() {
        try {
            const formData = this.getSampleFormData();
            
            const response = await fetch(`${this.apiUrl}/samples`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.success) {
                const patient = this.patients.find(p => p.id === result.sample.patientId);
                result.sample.patientName = patient ? patient.name : 'Unknown';
                
                this.samples.push(result.sample);
                this.currentSample = result.sample;
                this.saveToStorage();
                this.clearSampleForm();
                this.renderStepContent();
                this.showModal(this.translate('Success'), 'Sample added successfully');
            } else {
                this.showModal(this.translate('Error'), result.errors?.join('\n') || 'Failed to add sample');
            }
        } catch (error) {
            console.error('Error adding sample:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    getSampleFormData() {
        return {
            id: document.getElementById('sampleId')?.value.trim() || this.generateSampleId(),
            patientId: document.getElementById('samplePatientId')?.value || '',
            dateTime: document.getElementById('sampleDateTime')?.value || new Date().toISOString()
        };
    }

    generateSampleId() {
        return 'S' + Date.now().toString().slice(-6);
    }

    clearSampleForm() {
        ['sampleId', 'sampleDateTime'].forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.value = '';
                field.classList.remove('error', 'success');
            }
        });

        // Reset datetime to now
        const datetimeField = document.getElementById('sampleDateTime');
        if (datetimeField) {
            const now = new Date();
            now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
            datetimeField.value = now.toISOString().slice(0, 16);
        }
    }

    async generateSensorData() {
        try {
            const response = await fetch(`${this.apiUrl}/sensor-data/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({})
            });

            const result = await response.json();

            if (result.success) {
                this.sensorData = result.data;
                this.updateSensorDisplay();
                this.showModal(this.translate('Success'), 'Sensor data generated successfully');
            } else {
                this.showModal(this.translate('Error'), 'Failed to generate sensor data');
            }
        } catch (error) {
            console.error('Error generating sensor data:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    updateSensorDisplay() {
        // Update TCS34725 values
        if (this.sensorData.tcs34725) {
            const updateElement = (id, value) => {
                const element = document.getElementById(id);
                if (element) element.textContent = value;
            };

            updateElement('sensorR', this.sensorData.tcs34725.R);
            updateElement('sensorG', this.sensorData.tcs34725.G);
            updateElement('sensorB', this.sensorData.tcs34725.B);
            updateElement('sensorClear', this.sensorData.tcs34725.Clear);
        }

        // Update arrays and show data source
        this.renderStepContent();
        
        // Show data source info if available
        if (this.sensorData.source === 'excel_upload') {
            setTimeout(() => {
                const sensorSection = document.querySelector('.sensor-outputs');
                if (sensorSection) {
                    const sourceInfo = document.createElement('div');
                    sourceInfo.className = 'data-source-info';
                    sourceInfo.style.cssText = `
                        background: var(--color-bg-3);
                        padding: 12px;
                        border-radius: 8px;
                        margin-top: 16px;
                        border-left: 4px solid var(--color-success);
                        font-size: 14px;
                    `;
                    sourceInfo.innerHTML = `
                        <i class="fas fa-file-excel" style="color: var(--color-success); margin-right: 8px;"></i>
                        <strong>${this.currentLanguage === 'ar' ? 'مصدر البيانات' : 'Data Source'}:</strong>
                        ${this.currentLanguage === 'ar' ? 'ملف Excel مرفوع' : 'Excel File Upload'} - ${this.sensorData.fileName}
                        <br>
                        <small style="color: var(--color-text-secondary);">
                            ${this.currentLanguage === 'ar' ? 'تم التحميل في' : 'Uploaded at'}: ${new Date(this.sensorData.uploadTime).toLocaleString()}
                        </small>
                    `;
                    sensorSection.appendChild(sourceInfo);
                }
            }, 100);
        }
    }

    async processSignals() {
        try {
            if (!this.sensorData.impedance) {
                this.showModal(this.translate('Error'), 'No sensor data available for processing');
                return;
            }

            const filters = {
                movingAvg3: document.getElementById('movingAvg3')?.checked || false,
                movingAvg5: document.getElementById('movingAvg5')?.checked || false,
                movingAvg7: document.getElementById('movingAvg7')?.checked || false,
                medianFilter3: document.getElementById('medianFilter3')?.checked || false,
                medianFilter5: document.getElementById('medianFilter5')?.checked || false
            };

            const response = await fetch(`${this.apiUrl}/signal/process`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    signal: this.sensorData.impedance,
                    filters
                })
            });

            const result = await response.json();

            if (result.success) {
                this.processedData = result.processed;
                this.renderStepContent();
                this.updateSignalChart();
                this.showModal(
                    this.translate('Success'), 
                    `Signal processing completed with ${this.processedData.filters.length} filters`
                );
            } else {
                this.showModal(this.translate('Error'), 'Signal processing failed');
            }
        } catch (error) {
            console.error('Error processing signals:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    updateSignalChart() {
        const ctx = document.getElementById('signalChart');
        if (!ctx || !this.processedData.original || !this.processedData.processed) return;

        // Destroy existing chart
        if (window.signalChartInstance) {
            window.signalChartInstance.destroy();
        }

        const original = this.processedData.original;
        const processed = this.processedData.processed;

        try {
            window.signalChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: Array.from({length: Math.max(original.length, processed.length)}, (_, i) => i + 1),
                    datasets: [{
                        label: 'Original Signal',
                        data: original,
                        borderColor: '#FF5459',
                        backgroundColor: 'transparent',
                        borderWidth: 1,
                        pointRadius: 2
                    }, {
                        label: 'Processed Signal',
                        data: processed,
                        borderColor: '#32B8CD',
                        backgroundColor: 'transparent',
                        borderWidth: 2,
                        pointRadius: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        x: { 
                            title: { display: true, text: 'Sample Number' }
                        },
                        y: { 
                            title: { display: true, text: 'Amplitude' }
                        }
                    },
                    plugins: {
                        legend: { 
                            display: true, 
                            position: 'top' 
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error updating chart:', error);
        }
    }

    async calculateCBC() {
        try {
            if (!this.sensorData.tcs34725 || !this.sensorData.impedance) {
                this.showModal(this.translate('Error'), 'Sensor data required for CBC calculation');
                return;
            }

            const response = await fetch(`${this.apiUrl}/cbc/calculate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    sensorData: this.sensorData,
                    patientData: this.currentPatient
                })
            });

            const result = await response.json();

            if (result.success) {
                this.calculatedResults = result.results;
                this.renderStepContent();
                this.showModal(this.translate('Success'), 'CBC calculations completed');
            } else {
                this.showModal(this.translate('Error'), 'CBC calculation failed');
            }
        } catch (error) {
            console.error('Error calculating CBC:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    async updateInterpretation() {
        try {
            if (!this.calculatedResults || Object.keys(this.calculatedResults).length <= 1) {
                this.showModal(this.translate('Error'), 'Results required for interpretation');
                return;
            }

            const response = await fetch(`${this.apiUrl}/interpretation`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    results: this.calculatedResults,
                    patientData: this.currentPatient,
                    language: this.currentLanguage
                })
            });

            const result = await response.json();

            if (result.success) {
                this.interpretationResults = result.interpretation;
                this.renderStepContent();
            } else {
                this.showModal(this.translate('Error'), 'Interpretation failed');
            }
        } catch (error) {
            console.error('Error updating interpretation:', error);
            this.showModal(this.translate('Error'), 'Network error. Please try again.');
        }
    }

    // Excel file handling methods
    downloadExcelTemplate() {
        try {
            if (typeof createSensorTemplate === 'function') {
                createSensorTemplate();
                this.showModal(
                    this.translate('Success'), 
                    this.currentLanguage === 'ar' ? 
                        'تم تحميل قالب Excel بنجاح. يحتوي على تنسيق البيانات المطلوب للحساسات الثلاثة.' :
                        'Excel template downloaded successfully. It contains the required format for all three sensors.'
                );
            } else {
                throw new Error('Template creation function not available');
            }
        } catch (error) {
            console.error('Error downloading template:', error);
            this.showModal(this.translate('Error'), 'Failed to download Excel template');
        }
    }

    async uploadExcelFile() {
        const fileInput = document.getElementById('sensorExcelFile');
        const file = fileInput?.files[0];

        if (!file) {
            this.showModal(this.translate('Error'), 'Please select an Excel file first');
            return;
        }

        // Validate file type
        if (!file.name.match(/\.(xlsx|xls)$/i)) {
            this.showModal(
                this.translate('Error'), 
                this.currentLanguage === 'ar' ? 
                    'يجب أن يكون الملف من نوع Excel (.xlsx أو .xls)' :
                    'File must be an Excel file (.xlsx or .xls)'
            );
            return;
        }

        try {
            // Show loading state
            const uploadBtn = document.getElementById('uploadExcelBtn');
            if (uploadBtn) {
                uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                uploadBtn.disabled = true;
            }

            // Parse Excel file using the global function
            const parseResult = await parseSensorExcelFile(file);

            if (parseResult.errors.length > 0) {
                throw new Error(parseResult.errors.join('\n'));
            }

            // Validate the parsed data
            const validationErrors = validateSensorData(parseResult);
            if (validationErrors.length > 0) {
                throw new Error(validationErrors.join('\n'));
            }

            // Set the sensor data
            this.sensorData = {
                tcs34725: parseResult.tcs34725,
                photodiode: parseResult.photodiode,
                impedance: parseResult.impedance,
                source: 'excel_upload',
                fileName: file.name,
                uploadTime: new Date().toISOString()
            };

            // Update display
            this.updateSensorDisplay();

            // Reset file input
            fileInput.value = '';
            document.getElementById('selectedFileName').textContent = '';
            if (uploadBtn) {
                uploadBtn.style.display = 'none';
            }

            this.showModal(
                this.translate('Success'),
                this.currentLanguage === 'ar' ?
                    `تم تحميل ومعالجة ملف Excel بنجاح!\nالملف: ${file.name}\nتم تحميل بيانات الحساسات الثلاثة.` :
                    `Excel file uploaded and processed successfully!\nFile: ${file.name}\nAll three sensor datasets loaded.`
            );

        } catch (error) {
            console.error('Error processing Excel file:', error);
            this.showModal(
                this.translate('Error'), 
                this.currentLanguage === 'ar' ?
                    `خطأ في معالجة ملف Excel:\n${error.message}` :
                    `Error processing Excel file:\n${error.message}`
            );
        } finally {
            // Reset button state
            const uploadBtn = document.getElementById('uploadExcelBtn');
            if (uploadBtn) {
                uploadBtn.innerHTML = '<i class="fas fa-upload"></i> <span data-en="Upload & Process" data-ar="رفع ومعالجة">Upload & Process</span>';
                uploadBtn.disabled = false;
                this.updateTranslations(); // Re-apply translations
            }
        }
    }

    // Utility methods
    selectPatient(patientId) {
        this.currentPatient = this.patients.find(p => p.id === patientId);
        if (this.currentPatient) {
            this.showModal(this.translate('Success'), 
                `Selected patient: ${this.currentPatient.name}`);
        }
    }

    editPatient(patientId) {
        const patient = this.patients.find(p => p.id === patientId);
        if (patient) {
            document.getElementById('patientId').value = patient.id;
            document.getElementById('patientName').value = patient.name;
            document.getElementById('patientAge').value = patient.age;
            document.getElementById('patientSex').value = patient.sex;
            document.getElementById('patientDate').value = patient.date;
        }
    }

    deletePatient(patientId) {
        if (confirm('Are you sure you want to delete this patient?')) {
            this.patients = this.patients.filter(p => p.id !== patientId);
            this.saveToStorage();
            this.renderStepContent();
        }
    }

    selectSample(sampleId) {
        this.currentSample = this.samples.find(s => s.id === sampleId);
        if (this.currentSample) {
            // Ensure we have the correct patient selected
            this.currentPatient = this.patients.find(p => p.id === this.currentSample.patientId);
            this.showModal(this.translate('Success'), 
                `Selected sample: ${this.currentSample.id}`);
        }
    }

    deleteSample(sampleId) {
        if (confirm('Are you sure you want to delete this sample?')) {
            this.samples = this.samples.filter(s => s.id !== sampleId);
            this.saveToStorage();
            this.renderStepContent();
        }
    }

    viewTestResult(index) {
        const test = this.testHistory[index];
        if (test) {
            this.showModal('Test Result', 
                `Patient: ${test.patientName}\nSample: ${test.sampleId}\nDate: ${new Date(test.timestamp).toLocaleString()}`);
        }
    }

    exportCSV() {
        if (!this.calculatedResults || Object.keys(this.calculatedResults).length <= 1) {
            this.showModal(this.translate('Error'), 'No results available to export');
            return;
        }

        try {
            const headers = ['Parameter', 'Value', 'Unit', 'Method', 'Reference Range', 'Status'];
            const rows = [headers];

            const patientSex = this.currentPatient ? this.currentPatient.sex : 'male';
            const ranges = this.referenceRanges[patientSex];

            Object.keys(this.calculatedResults).forEach(param => {
                if (param === 'timestamp' || param === 'patientId') return;
                
                const result = this.calculatedResults[param];
                const range = ranges[param];
                
                let status = 'Normal';
                if (range) {
                    if (result.value < range.min) status = 'Low';
                    else if (result.value > range.max) status = 'High';
                }

                rows.push([
                    param.toUpperCase(),
                    result.value,
                    result.unit,
                    result.method,
                    range ? `${range.min}-${range.max} ${range.unit}` : 'N/A',
                    status
                ]);
            });

            const csvContent = rows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
            this.downloadFile(csvContent, 'text/csv', 'CBC_Results.csv');
            
            this.showModal(this.translate('Success'), 'CSV file downloaded successfully');
        } catch (error) {
            console.error('Error exporting CSV:', error);
            this.showModal(this.translate('Error'), 'Failed to export CSV file');
        }
    }

    generatePDF() {
        if (!this.calculatedResults || !this.currentPatient || Object.keys(this.calculatedResults).length <= 1) {
            this.showModal(this.translate('Error'), 'Patient and results data required');
            return;
        }

        try {
            if (typeof window.jsPDF === 'undefined') {
                this.showModal(this.translate('Error'), 'PDF library not loaded');
                return;
            }

            const { jsPDF } = window.jsPDF;
            const doc = new jsPDF();

            // Header
            doc.setFontSize(20);
            doc.setFont(undefined, 'bold');
            doc.text('CBC Analysis Report', 20, 20);

            doc.setFontSize(12);
            doc.setFont(undefined, 'normal');
            doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);

            // Patient Information
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.text('Patient Information', 20, 50);

            doc.setFontSize(11);
            doc.setFont(undefined, 'normal');
            let yPos = 60;
            doc.text(`Patient ID: ${this.currentPatient.id}`, 20, yPos);
            doc.text(`Name: ${this.currentPatient.name}`, 20, yPos + 10);
            doc.text(`Age: ${this.currentPatient.age} years`, 20, yPos + 20);
            doc.text(`Sex: ${this.currentPatient.sex}`, 20, yPos + 30);

            if (this.currentSample) {
                doc.text(`Sample ID: ${this.currentSample.id}`, 20, yPos + 40);
                doc.text(`Collection: ${new Date(this.currentSample.dateTime).toLocaleString()}`, 20, yPos + 50);
            }

            // Results
            yPos = 130;
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.text('CBC Results', 20, yPos);

            yPos += 15;
            doc.setFontSize(11);
            doc.setFont(undefined, 'normal');

            Object.keys(this.calculatedResults).forEach(param => {
                if (param === 'timestamp' || param === 'patientId') return;
                
                const result = this.calculatedResults[param];
                doc.text(`${param.toUpperCase()}: ${result.value} ${result.unit}`, 20, yPos);
                yPos += 10;
                
                if (yPos > 280) {
                    doc.addPage();
                    yPos = 20;
                }
            });

            // Save PDF
            const filename = `CBC_Report_${this.currentPatient.id}_${new Date().toISOString().split('T')[0]}.pdf`;
            doc.save(filename);

            this.showModal(this.translate('Success'), 'PDF report generated successfully');

            // Save to test history
            this.testHistory.push({
                timestamp: new Date().toISOString(),
                patientName: this.currentPatient.name,
                patientId: this.currentPatient.id,
                sampleId: this.currentSample ? this.currentSample.id : 'N/A',
                results: { ...this.calculatedResults }
            });
            this.saveToStorage();

        } catch (error) {
            console.error('Error generating PDF:', error);
            this.showModal(this.translate('Error'), 'Failed to generate PDF report');
        }
    }

    downloadFile(content, mimeType, filename) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
    }

    // Enhanced modal system
    showModal(title, message) {
        const modal = document.getElementById('alertModal');
        const titleElement = document.getElementById('modalTitle');
        const messageElement = document.getElementById('modalMessage');

        if (modal && titleElement && messageElement) {
            titleElement.textContent = title;
            messageElement.textContent = message;
            modal.classList.remove('hidden');
        } else {
            // Fallback to alert if modal not available
            alert(`${title}: ${message}`);
        }
    }

    hideModal() {
        const modal = document.getElementById('alertModal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    setDefaultDates() {
        const today = new Date().toISOString().split('T')[0];
        const patientDate = document.getElementById('patientDate');
        if (patientDate && !patientDate.value) {
            patientDate.value = today;
        }

        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        const sampleDateTime = document.getElementById('sampleDateTime');
        if (sampleDateTime && !sampleDateTime.value) {
            sampleDateTime.value = now.toISOString().slice(0, 16);
        }
    }

    updateUI() {
        this.updateStepDisplay();
        this.updateNavigationButtons();
        this.updateTranslations();
        
        // Set language select to current language
        const languageSelect = document.getElementById('languageSelect');
        if (languageSelect) {
            languageSelect.value = this.currentLanguage;
        }
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        window.app = new CBCAnalyzer();
        console.log('CBC Analyzer application started successfully');
    } catch (error) {
        console.error('Failed to initialize CBC Analyzer:', error);
        document.getElementById('app-content').innerHTML = `
            <div style="text-align: center; padding: 40px; color: #e74c3c;">
                <h3>Application Error</h3>
                <p>Failed to initialize CBC Analyzer. Please refresh the page.</p>
                <button onclick="location.reload()" style="padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Reload Page
                </button>
            </div>
        `;
    }
});

// Global error handling
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    if (window.app) {
        window.app.showModal('Error', 'An unexpected error occurred. Please try again.');
    }
});