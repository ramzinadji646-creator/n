/**
 * إنشاء قالب Excel للحساسات
 * Creates Excel template for sensor data
 */

function createSensorTemplate() {
    // إنشاء workbook جديد
    const wb = XLSX.utils.book_new();
    
    // بيانات TCS34725 Color Sensor
    const tcs34725Data = [
        ['TCS34725 Color Sensor Data - بيانات حساس الألوان'],
        ['Reading #', 'Red (R)', 'Green (G)', 'Blue (B)', 'Clear', 'Notes - ملاحظات'],
        ['قراءة رقم', 'أحمر', 'أخضر', 'أزرق', 'شفاف', ''],
        [1, 165, 125, 95, 210, 'Normal blood sample - عينة دم طبيعية'],
        [2, 158, 118, 88, 195, 'Normal blood sample - عينة دم طبيعية'],
        [3, 172, 132, 102, 225, 'Normal blood sample - عينة دم طبيعية'],
        [4, 160, 120, 90, 200, 'Normal blood sample - عينة دم طبيعية'],
        [5, 168, 128, 98, 215, 'Normal blood sample - عينة دم طبيعية'],
        ['', '', '', '', '', ''],
        ['المعدل الطبيعي:', '120-180', '100-160', '80-150', '150-250', 'Normal Range'],
        ['', '', '', '', '', ''],
        ['ملاحظات:', '', '', '', '', ''],
        ['- يجب أن تكون جميع القيم رقمية', '', '', '', '', ''],
        ['- المعدل الطبيعي للدم البشري موضح أعلاه', '', '', '', '', ''],
        ['- يمكن إضافة المزيد من القراءات حسب الحاجة', '', '', '', '', '']
    ];

    // بيانات Photodiode Array
    const photodiodeData = [
        ['Photodiode Array Data (10 Channels) - بيانات مصفوفة الضوئي'],
        ['Reading #', 'Ch1', 'Ch2', 'Ch3', 'Ch4', 'Ch5', 'Ch6', 'Ch7', 'Ch8', 'Ch9', 'Ch10', 'Notes'],
        ['قراءة رقم', 'قناة 1', 'قناة 2', 'قناة 3', 'قناة 4', 'قناة 5', 'قناة 6', 'قناة 7', 'قناة 8', 'قناة 9', 'قناة 10', 'ملاحظات'],
        [1, 1.245, 1.332, 1.156, 1.423, 1.298, 1.087, 1.367, 1.112, 1.445, 1.203, 'Light absorption values - قيم الامتصاص الضوئي'],
        [2, 1.198, 1.287, 1.123, 1.389, 1.256, 1.034, 1.321, 1.089, 1.398, 1.167, ''],
        [3, 1.267, 1.354, 1.178, 1.445, 1.321, 1.112, 1.389, 1.134, 1.467, 1.234, ''],
        [4, 1.223, 1.298, 1.145, 1.401, 1.278, 1.067, 1.345, 1.098, 1.423, 1.189, ''],
        [5, 1.289, 1.376, 1.201, 1.467, 1.343, 1.134, 1.412, 1.156, 1.489, 1.256, ''],
        ['', '', '', '', '', '', '', '', '', '', '', ''],
        ['المعدل:', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', '1.0-1.5', 'Range'],
        ['', '', '', '', '', '', '', '', '', '', '', ''],
        ['الوحدة: Absorbance Units (AU)', '', '', '', '', '', '', '', '', '', '', ''],
        ['يقيس امتصاص الضوء عبر العينة', '', '', '', '', '', '', '', '', '', '', '']
    ];

    // بيانات Impedance Sensor  
    const impedanceData = [
        ['Impedance Sensor Data (20 Channels) - بيانات حساس المقاومة'],
        ['Reading #', 'Ch1', 'Ch2', 'Ch3', 'Ch4', 'Ch5', 'Ch6', 'Ch7', 'Ch8', 'Ch9', 'Ch10', 'Ch11', 'Ch12', 'Ch13', 'Ch14', 'Ch15', 'Ch16', 'Ch17', 'Ch18', 'Ch19', 'Ch20', 'Notes'],
        ['قراءة رقم', 'ق1', 'ق2', 'ق3', 'ق4', 'ق5', 'ق6', 'ق7', 'ق8', 'ق9', 'ق10', 'ق11', 'ق12', 'ق13', 'ق14', 'ق15', 'ق16', 'ق17', 'ق18', 'ق19', 'ق20', 'ملاحظات'],
        [1, 2.34, 0.151, 0.11, 0.15, 1.8, 0.145, 0.109, 2.048, 0.15, 2.466, 0.172, 0.158, 1.707, 0.123, 1.604, 0.159, 1.961, 2.249, 0.123, 1.967, 'Cell counting pulses - نبضات عد الخلايا'],
        [2, 1.95, 0.134, 0.098, 0.142, 2.12, 0.156, 0.121, 1.876, 0.163, 2.123, 0.148, 0.176, 1.543, 0.134, 1.789, 0.142, 2.087, 1.934, 0.156, 2.234, ''],
        [3, 2.156, 0.167, 0.123, 0.189, 1.67, 0.134, 0.098, 2.234, 0.145, 2.345, 0.189, 0.134, 1.876, 0.167, 1.432, 0.178, 1.789, 2.123, 0.145, 1.798, ''],
        [4, 2.087, 0.145, 0.134, 0.156, 1.934, 0.178, 0.112, 2.009, 0.167, 2.567, 0.134, 0.189, 1.654, 0.145, 1.723, 0.156, 2.134, 2.087, 0.178, 2.009, ''],
        [5, 1.876, 0.189, 0.145, 0.134, 2.234, 0.167, 0.134, 1.798, 0.156, 2.234, 0.167, 0.145, 1.798, 0.189, 1.567, 0.134, 1.876, 1.934, 0.167, 2.156, ''],
        ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
        ['نوع النبضة:', 'خلية', 'ضوضاء', 'ضوضاء', 'ضوضاء', 'خلية', 'ضوضاء', 'ضوضاء', 'خلية', 'ضوضاء', 'خلية', 'ضوضاء', 'ضوضاء', 'خلية', 'ضوضاء', 'خلية', 'ضوضاء', 'خلية', 'خلية', 'ضوضاء', 'خلية', 'Pulse Type'],
        ['حد الكشف:', '>1.5', '<0.5', '<0.5', '<0.5', '>1.5', '<0.5', '<0.5', '>1.5', '<0.5', '>1.5', '<0.5', '<0.5', '>1.5', '<0.5', '>1.5', '<0.5', '>1.5', '>1.5', '<0.5', '>1.5', 'Detection'],
        ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
        ['الوحدة: Impedance (Ω)', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
        ['القيم >1.5: نبضات الخلايا', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''],
        ['القيم <0.5: ضوضاء الخلفية', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    ];

    // إنشاء worksheets
    const ws1 = XLSX.utils.aoa_to_sheet(tcs34725Data);
    const ws2 = XLSX.utils.aoa_to_sheet(photodiodeData);  
    const ws3 = XLSX.utils.aoa_to_sheet(impedanceData);

    // تنسيق العرض
    ws1['!cols'] = [
        {wch: 12}, {wch: 10}, {wch: 10}, {wch: 10}, {wch: 10}, {wch: 35}
    ];
    
    ws2['!cols'] = [
        {wch: 12}, ...Array(10).fill({wch: 8}), {wch: 30}
    ];
    
    ws3['!cols'] = [
        {wch: 12}, ...Array(20).fill({wch: 6}), {wch: 25}
    ];

    // إضافة worksheets إلى workbook
    XLSX.utils.book_append_sheet(wb, ws1, "TCS34725_ColorSensor");
    XLSX.utils.book_append_sheet(wb, ws2, "Photodiode_Array");
    XLSX.utils.book_append_sheet(wb, ws3, "Impedance_Sensor");

    // تنزيل الملف
    XLSX.writeFile(wb, "CBC_Sensor_Data_Template.xlsx");
}

// دالة لقراءة ملف Excel المرفوع
function parseSensorExcelFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, {type: 'array'});
                
                const result = {
                    tcs34725: null,
                    photodiode: null,
                    impedance: null,
                    errors: []
                };

                // قراءة TCS34725 data
                if (workbook.SheetNames.includes('TCS34725_ColorSensor')) {
                    const sheet = workbook.Sheets['TCS34725_ColorSensor'];
                    const jsonData = XLSX.utils.sheet_to_json(sheet, {header: 1});
                    
                    // البحث عن البيانات (تبدأ من الصف 4)
                    for (let i = 3; i < jsonData.length; i++) {
                        const row = jsonData[i];
                        if (row && row.length >= 5 && typeof row[1] === 'number') {
                            result.tcs34725 = {
                                R: Math.round(row[1]) || 150,
                                G: Math.round(row[2]) || 120, 
                                B: Math.round(row[3]) || 100,
                                Clear: Math.round(row[4]) || 200
                            };
                            break;
                        }
                    }
                }

                // قراءة Photodiode data
                if (workbook.SheetNames.includes('Photodiode_Array')) {
                    const sheet = workbook.Sheets['Photodiode_Array'];
                    const jsonData = XLSX.utils.sheet_to_json(sheet, {header: 1});
                    
                    // البحث عن البيانات (تبدأ من الصف 4)
                    for (let i = 3; i < jsonData.length; i++) {
                        const row = jsonData[i];
                        if (row && row.length >= 11 && typeof row[1] === 'number') {
                            result.photodiode = [];
                            for (let j = 1; j <= 10; j++) {
                                result.photodiode.push(Number((row[j] || 1.0).toFixed(3)));
                            }
                            break;
                        }
                    }
                }

                // قراءة Impedance data
                if (workbook.SheetNames.includes('Impedance_Sensor')) {
                    const sheet = workbook.Sheets['Impedance_Sensor'];
                    const jsonData = XLSX.utils.sheet_to_json(sheet, {header: 1});
                    
                    // البحث عن البيانات (تبدأ من الصف 4)
                    for (let i = 3; i < jsonData.length; i++) {
                        const row = jsonData[i];
                        if (row && row.length >= 21 && typeof row[1] === 'number') {
                            result.impedance = [];
                            for (let j = 1; j <= 20; j++) {
                                result.impedance.push(Number((row[j] || 0.1).toFixed(3)));
                            }
                            break;
                        }
                    }
                }

                // التحقق من وجود البيانات المطلوبة
                if (!result.tcs34725) {
                    result.errors.push('TCS34725 Color Sensor data not found or invalid');
                }
                if (!result.photodiode) {
                    result.errors.push('Photodiode Array data not found or invalid');
                }
                if (!result.impedance) {
                    result.errors.push('Impedance Sensor data not found or invalid');
                }

                resolve(result);
                
            } catch (error) {
                reject(new Error('Error parsing Excel file: ' + error.message));
            }
        };
        
        reader.onerror = function() {
            reject(new Error('Error reading file'));
        };
        
        reader.readAsArrayBuffer(file);
    });
}

// التحقق من صحة بيانات الحساسات
function validateSensorData(sensorData) {
    const errors = [];
    
    // التحقق من TCS34725
    if (sensorData.tcs34725) {
        const { R, G, B, Clear } = sensorData.tcs34725;
        if (R < 0 || R > 300) errors.push('TCS34725 Red value should be between 0-300');
        if (G < 0 || G > 300) errors.push('TCS34725 Green value should be between 0-300');
        if (B < 0 || B > 300) errors.push('TCS34725 Blue value should be between 0-300');
        if (Clear < 0 || Clear > 400) errors.push('TCS34725 Clear value should be between 0-400');
    }
    
    // التحقق من Photodiode
    if (sensorData.photodiode && sensorData.photodiode.length === 10) {
        sensorData.photodiode.forEach((val, idx) => {
            if (val < 0.5 || val > 2.0) {
                errors.push(`Photodiode channel ${idx + 1} value should be between 0.5-2.0`);
            }
        });
    }
    
    // التحقق من Impedance
    if (sensorData.impedance && sensorData.impedance.length === 20) {
        sensorData.impedance.forEach((val, idx) => {
            if (val < 0 || val > 5.0) {
                errors.push(`Impedance channel ${idx + 1} value should be between 0-5.0`);
            }
        });
    }
    
    return errors;
}